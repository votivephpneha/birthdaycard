<?php

namespace App\Http\Controllers\Front;

use App\Http\Controllers\Controller;
use App\Http\Requests;
use Illuminate\Http\Request;
use File;
use Session;
use Illuminate\Support\Str;
use App\Models\User;
use DB,Validator;
use Hash;
use Auth;

class CustomerController extends Controller{

	public function index(){
		return view("Front/register");
	}

	public function submitUser(Request $request){
		
        $user = User::where('email', '=', $request->email)->first();
        if($user){
        	session::flash('email_error', 'Email already exist.');
        	return redirect()->route('registration');
        }else{

			$users = DB::table('users')->insert(['fname'=>$request->fname,'lname'=>$request->lname,'email'=>$request->email,'password'=>Hash::make($request->password),'role'=>'user','status'=>'Active']);

			session::flash('success', 'User registered successfully.');
			return redirect()->route('registration');
        }
	}

	public function loginUser(){
		return view("Front/login");
	}

	public function submitloginUser(Request $request){
		$user_data = array(
	      'email'  => $request->get('email'),
	      'password' => $request->get('password')
	    );
        
		if(Auth::attempt($user_data))
		{
			return redirect()->route('userProfile');
		}
		else
		{
			return back()->with('error', 'Wrong Login Details');
		}
	}

	public function userProfile(){
		$user = array(
			'fname'=>Auth::User()->fname,
			'lname'=>Auth::User()->lname,
			'email'=>Auth::User()->email
			
		);
		
		return view("Front/userProfile",['user_data'=>$user]);
	}

	public function postuserProfile(Request $request){
		$file = $request->file('profile_image');
        $destinationPath = base_path() .'/public/user/upload';
        $file->move($destinationPath,$file->getClientOriginalName());

		$user_id = Auth::User()->id;
		$user = User::find($user_id);
        $user->fname = $request->fname;
        $user->lname = $request->lname;
        $user->email = $request->email;
        $user->image = $request->email;
        $user->update();

        session::flash('success', 'Profile updated successfully.');

        return redirect()->route('userProfile');
	}

	public function front_logout()
    {
        
        Auth::logout();
        return Redirect("/loginUser");
    }
}