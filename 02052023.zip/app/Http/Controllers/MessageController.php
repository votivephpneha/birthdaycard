<?php

namespace App\Http\Controllers;
// use App\Http\Controllers\Controller;
use App\Models\Message;
use Illuminate\Http\Request;

class MessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return  view('Admin.admintmessagepages.textmessage_list');
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return  view('Admin.admintmessagepages.create_textmessage');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate([
            "text_mess" => "required",
            "mess_status" => "required",           
        ]);

        if ($request->mess_status == 1) {
            $status = "Active";
        } else {
            $status = "Inactive";
        }

        $textmess = new Message();
        $textmess->text_message = $request->text_mess;      
        $textmess->status = $status;
        $textmess->save();

        return redirect("admin/textmessagelist")->with(
            "success",
            "message added successfully"
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function show(Message $message)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function edit(Message $message,$id)
    {
        $messdata =  Message::find($id);
        return view('Admin.admintmessagepages.edit_textmessage',compact('messdata'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Message $message,$id)
    {
        $request->validate([
            "text_mess" => "required",
            "mess_status" => "required",
        ]);

        $textmessfind = Message::find($id);
        if (empty($textmessfind)) {
            return back()->with("failed", "Data not found");
        } else {
            if ($request->mess_status == 1) {
                $status = "Active";
            } else {
                $status = "Inactive";
            }
            
            $textmessfind->text_message = $request->text_mess ;
            $textmessfind->status = $status;
            $textmessfind->save();

            return redirect("admin/textmessagelist")->with(
                "success",
                " Text message updated successfully"
            );
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function destroy(Request $request)
    {
        $textmesslist = Message::find($request->id);
         $textmesslist->delete();
         return response()->json('success');
    }

    // get message list
    public function getTextmessagelist(Request $request)
    {
        $totalFilteredRecord = $totalDataRecord = $draw_val = "";
        $columns_list = array(
        0 =>'id',
        1 =>'srno',
        2=> 'textmessage',              
        3=> 'status',
        4=> 'action'
        );
            
        $totalDataRecord = Message::count();
            
        $totalFilteredRecord = $totalDataRecord;
            
        $limit_val = $request->input('length');
        $start_val = $request->input('start');
        $order_val = $columns_list[$request->input('order.0.column')];
        $dir_val = $request->input('order.0.dir');
            
        if(empty($request->input('search.value')))
        {
        $mess_data = Message::offset($start_val)
        ->limit($limit_val)
        ->orderBy('id', 'ASC')
        // ->orderBy($order_val,$dir_val)
        ->get();
        }
        else {
        $search_text = $request->input('search.value');

        $mess_data = Message::select("id","text_message", "status")
                            ->where(function ($query) use ($search_text) {
                                $query->where('id', 'LIKE',"%{$search_text}%")
                                ->orWhere('text_message', 'LIKE',"%{$search_text}%")
                                ->orWhere('status', 'LIKE',"%{$search_text}%");
        
                            })
                            ->offset($start_val)
                            ->limit($limit_val)
                            ->orderBy('id', 'ASC')
                            // ->orderBy($order_val,$dir_val)
                            ->get();

        $totalFilteredRecord = Message::select("id","text_message", "status")
                            ->where(function ($query) use ($search_text) {
                                $query->where('id', 'LIKE',"%{$search_text}%")
                                        ->orWhere('text_message', 'LIKE',"%{$search_text}%")
                                        ->orWhere('status', 'LIKE',"%{$search_text}%");
            
                            })
                            ->offset($start_val)
                            ->limit($limit_val)
                            ->orderBy($order_val,$dir_val)
                            ->count();
        }
            
        $data_val = array();
        if(!empty($mess_data))
        {
            $i = $start_val+1;
        //  echo"<pre>",print_r($user_data);die;
        foreach ($mess_data as $value)
        {
          
        
            $nestedData['id'] = $value->id;
            $nestedData['srno'] = $i;
            $nestedData['textmessage'] = $value->text_message;  
                   
                if($value->status == "Active"){
                $nestedData['status'] ='<span class="label label-success">'.$value->status.'</span>';
            }else{
                $nestedData['status'] = '<span class="label label-danger">'.$value->status.'</span>';
            }
            
            $nestedData['action'] = '<button class="btn btn-dark p-2" >
            <a href="'.route('edit.message',[$value->id]) .' " class="text-white" style=" color: #FFFFFF;"><i class="fa fa-edit" ></i>Edit</button></a>
            <button class="btn  btn-dark p-2" >
            <a href="javascript:void(0);" onClick="delete_message('.$value->id.')" data-id="'.$value->id.'" class="text-white delete-text-mess'.$value->id.'" style=" color: #FFFFFF;"><i class="fa fa-trash-o"></i> Delete </button></a>';
            
            $data_val[] = $nestedData;

            $i++;
                    
        }
        }
        $draw_val = $request->input('draw');
        $get_json_data = array(
        "draw"            => intval($draw_val),
        "recordsTotal"    => intval($totalDataRecord),
        "recordsFiltered" => intval($totalFilteredRecord),
        "data"            => $data_val
        );
            
        echo json_encode($get_json_data);  
 
    }
}
