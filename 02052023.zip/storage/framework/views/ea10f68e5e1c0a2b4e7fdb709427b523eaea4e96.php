<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Edit Customer</title>

    
    <!-- custom css -->
    <?php echo $__env->make('Admin.custom_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <style>

    .field-icon {

    float: right;


    margin-top: -25px;

    position: relative;

    z-index: 2;

    }

    </style>
  </head>

  <body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <?php echo $__env->make('Admin.template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!-- top navigation -->
         <div class="top_nav">
          <div class="nav_menu">
            <nav>
              <div class="nav toggle">
                <a id="menu_toggle"><i class="fa fa-bars"></i></a>
              </div>

              <ul class="nav navbar-nav navbar-right">
                <li class="">
                  <a href="javascript:;" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                    <img src="<?php echo e(asset('public/images/img.jpg')); ?>" alt=""><?php echo e(Session::get('name')); ?>

                    <span class=" fa fa-angle-down"></span>
                  </a>
                  <ul class="dropdown-menu dropdown-usermenu pull-right">
                    <li><a href="<?php echo e(route('chagepassword')); ?>">Manage Account</a></li>                  
                    <li><a href="<?php echo e(route('logout')); ?>"><i class="fa fa-sign-out pull-right"></i>Log out</a></li>
                  </ul>
                </li>
                
              </ul>
            </nav>
          </div>
        </div>
        <!-- /top navigation -->

        <!-- page content -->
        <div class="right_col" role="main">
          <div class="">
            <div class="page-title">
              <div class="title_left">
                <h3>Edit Customer</h3>
              </div>

              <!-- <div class="title_right">
                <div class="col-md-5 col-sm-5 col-xs-12 form-group pull-right top_search">
                  <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search for...">
                    <span class="input-group-btn">
                      <button class="btn btn-default" type="button">Go!</button>
                    </span>
                  </div>
                </div>
              </div> -->
            </div>
            <div class="clearfix"></div>
            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                    <br />
                    <?php if(Session::has('success')): ?>
                     <div class="alert alert-success alert-block">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                          <strong><?php echo e(Session::get('success')); ?></strong>
                    </div>        
                    <?php endif; ?>

                    <?php if(Session::has('failed')): ?>
                     <div class="alert alert-danger alert-block">
                      <button type="button" class="close" data-dismiss="alert">×</button>
                          <strong><?php echo e(Session::get('failed')); ?></strong>
                    </div>        
                    <?php endif; ?>
                    <form id="demo-form2" data-parsley-validate class="form-horizontal form-label-left" method="POST" action="<?php echo e(route('edit-customer-post',$users->id)); ?>" enctype="multipart/form-data">
                     <?php echo csrf_field(); ?>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="first-name">First Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="name" name="name"  class="form-control col-md-7 col-xs-12" value="<?php echo e($users->fname); ?>">
                          <?php if($errors->has('name')): ?>

                        <span class="text-danger"><?php echo e($errors->first('name')); ?></span>

                        <?php endif; ?>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12" for="last-name">Last Name <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input type="text" id="last-name" name="last_name"  class="form-control col-md-7 col-xs-12" value="<?php echo e($users->lname); ?>">
                          <?php if($errors->has('last_name')): ?>

                        <span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>

                        <?php endif; ?>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Phone Number</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="middle-name" class="form-control col-md-7 col-xs-12" type="text" name="user_mob" value="<?php echo e($users->phone); ?>">
                          <?php if($errors->has('user_mob')): ?>

                        <span class="text-danger"><?php echo e($errors->first('user_mob')); ?></span>

                        <?php endif; ?>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Email</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="email-name" class="form-control col-md-7 col-xs-12" type="email" name="email" value="<?php echo e($users->email); ?>">
                          <?php if($errors->has('email')): ?>

                        <span class="text-danger"><?php echo e($errors->first('email')); ?></span>

                        <?php endif; ?>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Address</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="email-name" class="form-control col-md-7 col-xs-12" type="text" name="user_add" value="<?php echo e($users->address); ?>">
                          <?php if($errors->has('user_add')): ?>

                        <span class="text-danger"><?php echo e($errors->first('user_add')); ?></span>

                        <?php endif; ?>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">User Status</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                            <select name="user_status" id="user_status"  class="form-control">

                              <option value="1" <?php echo e($users->status == 'Active' ? 'selected' : ''); ?>>Active</option>

                              <option value="0" <?php echo e($users->status == 'Inactive' ? 'selected' : ''); ?>>Inactive</option>
                              

                            </select>
                            <?php if($errors->has('user_status')): ?>

                            <span class="text-danger"><?php echo e($errors->first('user_status')); ?></span>

                           <?php endif; ?>
                        </div>
                      </div>

                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Password</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                        <input  class="form-control col-md-7 col-xs-12" type="password" name="password" id="password-field"  value="<?php echo e($users->temp_password); ?>">
                        <span toggle="#password-field" class="fa fa-fw fa-eye field-icon toggle-password"> 
                          <?php if($errors->has('password')): ?>

                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>

                        <?php endif; ?> 
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Confirm Password</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="confirmpassword" class="form-control col-md-7 col-xs-12" type="password" name="confirmpassword" id="cpassword-field"> 
                          <!-- <span toggle="#cpassword-field" class="fa fa-fw fa-eye field-icon toggle-password"> -->
                           <?php if($errors->has('confirmpassword')): ?>

                        <span class="text-danger"><?php echo e($errors->first('confirmpassword')); ?></span>

                        <?php endif; ?> 
                        </div>
                       
                      </div>
                      <div class="form-group">
                        <label for="middle-name" class="control-label col-md-3 col-sm-3 col-xs-12">Profile</label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="confirmpassword" class="form-control col-md-7 col-xs-12" type="file" name="image" value="<?php echo e($users->image); ?>" accept="image/png, image/gif, image/jpeg" >

                          <img src="<?php echo e(asset('public/upload/user').'/'. $users->image); ?>" height="50" width="50">
                          <?php if($errors->has('image')): ?>

                        <span class="text-danger"><?php echo e($errors->first('image')); ?></span>

                        <?php endif; ?> 
                        </div>
                       
                      </div>
                      <!-- <div class="form-group">
                        <label class="control-label col-md-3 col-sm-3 col-xs-12">Date Of Birth <span class="required">*</span>
                        </label>
                        <div class="col-md-6 col-sm-6 col-xs-12">
                          <input id="birthday" name="Dob" class="date-picker form-control col-md-7 col-xs-12"  type="date" value="<?php echo e($users->dob); ?>">
                           <?php if($errors->has('Dob')): ?>

                        <span class="text-danger"><?php echo e($errors->first('Dob')); ?></span>

                        <?php endif; ?>
                        </div>
                       
                      </div> -->
                      <div class="ln_solid"></div>
                      <div class="form-group">
                        <div class="col-md-6 col-sm-6 col-xs-12 col-md-offset-3">
                          
                          <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>

                    </form>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
        <!-- /page content -->

        <!-- footer content -->
        <?php echo $__env->make('Admin.template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- /footer content -->
      </div>
    </div>

    
    <!-- custom js -->  
    <?php echo $__env->make('Admin.custom_js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script>

    $(".toggle-password").click(function() {

    $(this).toggleClass("fa-eye fa-eye-slash");

    var input = $($(this).attr("toggle"));

    if (input.attr("type") == "password") {

    input.attr("type", "text");

    } else {

    input.attr("type", "password");

    }

    });

    </script> 

  </body>
</html><?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Admin/edit_customer.blade.php ENDPATH**/ ?>