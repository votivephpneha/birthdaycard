

<!-- jQuery -->

<script src="<?php echo e(asset('public/vendors/jquery/dist/jquery.min.js')); ?>"></script>





 <!-- DATA TABLE JS-->

 <script src="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script>



<!-- Bootstrap -->

<script src="<?php echo e(asset('public/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>



<!-- Chart.js -->

<script src="<?php echo e(asset('public/vendors/Chart.js/dist/Chart.min.js')); ?>"></script>



<!-- bootstrap-progressbar -->

<script src="<?php echo e(asset('public/vendors/bootstrap-progressbar/bootstrap-progressbar.min.js')); ?>"></script>



<!-- bootstrap-daterangepicker -->

<script src="<?php echo e(asset('public/vendors/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>



<!-- bootstrap-wysiwyg -->

<script src="<?php echo e(asset('public/vendors/bootstrap-wysiwyg/js/bootstrap-wysiwyg.min.js')); ?>"></script>

<!-- Autosize -->

<script src="<?php echo e(asset('public/vendors/autosize/dist/autosize.min.js')); ?>"></script>

<!-- jQuery autocomplete -->

<script src="<?php echo e(asset('public/vendors/devbridge-autocomplete/dist/jquery.autocomplete.min.js')); ?>"></script>



<!-- FastClick -->

<!-- <script src="<?php echo e(asset('vendors/fastclick/lib/fastclick.js')); ?>"></script> -->

<!-- NProgress -->

<!-- <script src="<?php echo e(asset('vendors/nprogress/nprogress.js')); ?>"></script> -->

<!-- iCheck -->

<!-- <script src="<?php echo e(asset('vendors/iCheck/icheck.min.js')); ?>"></script> -->

<!-- Datatables -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net/js/jquery.dataTables.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-bs/js/dataTables.bootstrap.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/buttons.flash.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-keytable/js/dataTables.keyTable.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/datatables.net-scroller/js/dataTables.scroller.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/jszip/dist/jszip.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/pdfmake/build/pdfmake.min.js')); ?>"></script> -->

<!-- <script src="<?php echo e(asset('vendors/pdfmake/build/vfs_fonts.js')); ?>"></script> -->



<!-- Custom Theme Scripts -->

<script src="<?php echo e(asset('public/build/js/custom.min.js')); ?>"></script>


<!--Ck editor js -->
<script src="https://cdn.ckeditor.com/4.11.1/standard/ckeditor.js"></script>













<?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Admin/custom_js.blade.php ENDPATH**/ ?>