<!DOCTYPE html>
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <!-- Meta, title, CSS, favicons, etc. -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Birthday Cards| </title>

    <?php echo $__env->make('Admin.custom_css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  </head>

  <body class="login">
    <div>
      <a class="hiddenanchor" id="signup"></a>
      <a class="hiddenanchor" id="signin"></a>

      <div class="login_wrapper">
        <?php if(Session::has('failed')): ?>
        <div class="alert alert-danger alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e(Session::get('failed')); ?></strong>
          </div>   
        <?php endif; ?>
        <?php if(Session::has('success')): ?>
        <div class="alert alert-success alert-block">
            <button type="button" class="close" data-dismiss="alert">×</button>
                <strong><?php echo e(Session::get('success')); ?></strong>
          </div>   
        <?php endif; ?>
        <div class="animate form login_form">
          <section class="login_content">
            <form method="POST" action="<?php echo e(route('login.post')); ?>">
              <?php echo csrf_field(); ?>
              <h1>Login Form</h1>
              <div>
                <input type="text" class="form-control" placeholder="Email" name="email" />
                <?php if($errors->has('email')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
              </div>
              <div>
                <input type="password" class="form-control" placeholder="Password" name="password"/>
                <?php if($errors->has('password')): ?>
                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                <?php endif; ?>
              </div>
              <div>
                <button type="submit" class="btn btn-default submit "  style="float:left!important;">
                  Log in
                 </button>
                <!-- <a class="" href="index.html"></a> -->
                <a class="reset_pass" href="">Lost your password?</a>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <!-- <p class="change_link">New to site?
                  <a href="" class="to_register"> Create Account </a>
                </p> -->

                <div class="clearfix"></div>
                <br />

                <!-- <div>
                  <h1><i class="fa fa-paw"></i> Birthday Cards !</h1>
                  <p>©2016 All Rights Reserved. Birthday Cards ! is a Bootstrap 3 template. Privacy and Terms</p>
                </div> -->
              </div>
            </form>
          </section>
        </div>

      <!--   <div id="register" class="animate form registration_form">
          <section class="login_content">
            <form action="" method="POST">
              <?php echo csrf_field(); ?>
              <h1>Create Account</h1>
              <div>
                <input type="text" class="form-control" placeholder="Username"   name="username"/>
              </div>
              <?php if($errors->has('username')): ?>
              <span style="color: red"><?php echo e($errors->first('username')); ?><span>
              <?php endif; ?>
              <div>
                <input type="email" class="form-control" placeholder="Email" required="" name="email" />
              </div>
               <?php if($errors->has('email')): ?>
              <span style="color: red"><?php echo e($errors->first('email')); ?><span>
              <?php endif; ?>
              <div>
                <input type="password" class="form-control" placeholder="Password" required="" name="password"/>
              </div>
              <?php if($errors->has('password')): ?>
              <span style="color: red"><?php echo e($errors->first('password')); ?><span>
              <?php endif; ?>
              <div>
                <button type="submit" class="btn btn-default">
                                  Register
                </button>
              </div>

              <div class="clearfix"></div>

              <div class="separator">
                <p class="change_link">Already a member ?
                  <a href="#signin" class="to_register"> Log in </a>
                </p>

                <div class="clearfix"></div>
                <br />

                <div>
                  <h1><i class="fa fa-paw"></i> Birthday Cards !</h1>
                  <p>©2016 All Rights Reserved. Birthday Cards ! is a Bootstrap 3 template. Privacy and Terms</p>
                </div>
              </div>
            </form>
          </section>
        </div> -->
      </div>
    </div>
  </body>
</html>
<?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Admin/adminauthpages/login.blade.php ENDPATH**/ ?>