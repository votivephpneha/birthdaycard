 <footer>
  <div class="pull-right">
    Gentelella - Bootstrap Admin Template by <a href="https://colorlib.com">Colorlib</a>
  </div>
  <div class="clearfix"></div>
</footer><?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Admin/template/footer.blade.php ENDPATH**/ ?>