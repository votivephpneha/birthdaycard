<!-- Bootstrap -->
<link href="<?php echo e(asset('public/vendors/bootstrap/dist/css/bootstrap.min.css')); ?>" rel="stylesheet">
<!-- Font Awesome -->
<link href="<?php echo e(asset('public/vendors/font-awesome/css/font-awesome.min.css')); ?>" rel="stylesheet">
<!-- NProgress -->
<!-- <link href="<?php echo e(asset('vendors/nprogress/nprogress.css')); ?>" rel="stylesheet"> -->
<!-- Animate.css -->
<link href="<?php echo e(asset('public/vendors/animate.css/animate.min.css')); ?>" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="<?php echo e(asset('public/build/css/custom.min.css')); ?>" rel="stylesheet">
	
<!-- bootstrap-progressbar -->
<link href="<?php echo e(asset('public/vendors/bootstrap-progressbar/css/bootstrap-progressbar-3.3.4.min.css')); ?>" rel="stylesheet">

<!-- bootstrap-daterangepicker -->
<link href="<?php echo e(asset('public/vendors/bootstrap-daterangepicker/daterangepicker.css')); ?>" rel="stylesheet">



<!-- Datatables -->
<!-- <link href="<?php echo e(asset('vendors/datatables.net-bs/css/dataTables.bootstrap.min.css')); ?>" rel="stylesheet"> -->
<!-- <link href="<?php echo e(asset('vendors/datatables.net-buttons-bs/css/buttons.bootstrap.min.css')); ?>" rel="stylesheet"> -->
<!-- <link href="<?php echo e(asset('vendors/datatables.net-fixedheader-bs/css/fixedHeader.bootstrap.min.css')); ?>" rel="stylesheet"> -->
<!-- <link href="<?php echo e(asset('vendors/datatables.net-responsive-bs/css/responsive.bootstrap.min.css')); ?>" rel="stylesheet"> -->
<!-- <link href="<?php echo e(asset('vendors/datatables.net-scroller-bs/css/scroller.bootstrap.min.css')); ?>" rel="stylesheet"> -->


<?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Admin/custom_css.blade.php ENDPATH**/ ?>