<!-- jQuery -->
<script src="<?php echo e(asset('public/vendors/jquery/dist/jquery.min.js')); ?>"></script>
<!-- Bootstrap -->
<script src="<?php echo e(asset('public/vendors/bootstrap/dist/js/bootstrap.min.js')); ?>"></script>
<!-- Custom Theme Scripts -->
<script src="<?php echo e(asset('public/build/js/custom.min.js')); ?>"></script>
<!-- DATA TABLE JS-->
<!-- <script src="https://code.jquery.com/jquery-3.5.1.js"></script> -->

<script src="https://cdn.datatables.net/1.13.3/js/jquery.dataTables.min.js"></script><?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Admin/template/datatable_script.blade.php ENDPATH**/ ?>