<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
	.error{
		color:red;
	}
	.user_registration{
		width:500px;
		margin: auto;
    margin-top: 60px;
	}
  ul, li, div {
    background: hsla(0, 0%, 0%, 0);
    border: 0;
    font-size: 100%;
    margin: 0;
    outline: 0;
    padding: 0;
    vertical-align: baseline;
    font: 13px/20px "Droid Sans", Arial, "Helvetica Neue", "Lucida Grande", sans-serif;
    text-shadow: 0 1px 0 hsl(0, 100%, 100%);
}
li {
    display: list-item;
    text-align: -webkit-match-parent;
}
.tabs-nav {
    list-style: none;
    margin: 0;
    padding: 0;
}
.tabs-nav li:first-child a {
    border-right: 0;
    -moz-border-radius-topleft: 6px;
    -webkit-border-top-left-radius: 6px;
    border-top-left-radius: 6px;
}
.tabs-nav .tab-active a {
    background: hsl(0, 100%, 100%);
    border-bottom-color: hsla(0, 0%, 0%, 0);
    color: hsl(85, 54%, 51%);
    cursor: default;
}
.tabs-nav a {
    background: hsl(120, 11%, 96%);
    border: 1px solid hsl(210, 6%, 79%);
    color: hsl(215, 6%, 57%);
    display: block;
    font-size: 11px;
    font-weight: bold;
    height: 40px;
    line-height: 44px;
    text-align: center;
    text-transform: uppercase;
    width: 250px;
}
.tabs-nav li {
    float: left;
}
.tabs-stage {
    border: 1px solid hsl(210, 6%, 79%);
    -webkit-border-radius: 0 0 6px 6px;
    -moz-border-radius: 0 0 6px 6px;
    -ms-border-radius: 0 0 6px 6px;
    -o-border-radius: 0 0 6px 6px;
    border-radius: 0 0 6px 6px;
    border-top: 0;
    clear: both;
    margin-bottom: 20px;
    position: relative;
    top: -1px;
    
}
.tabs-stage p {
    margin: 0;
    padding: 20px;
    color: hsl(0, 0%, 33%);
}
.user-profile-tab{
  padding: 20px;
}
</style>

<div class="container">
  <div class="user_registration">
     <ul class="tabs-nav">
    <li class=""><a class="tab-link" href="#tab-1" rel="nofollow">Features</a>
    </li>
    <li class="tab-active1"><a class="tab-link1" href="<?php echo e(url('user/front_logout')); ?>" rel="nofollow">Logout</a>
    </li>
</ul>
<!-- <a href="<?php echo e(url('user/front_logout')); ?>" rel="nofollow">Logout</a> -->
<div class="tabs-stage">
    <div id="tab-1" class="tab-stage-div" style="display: none;">
      <div class="user-profile-tab">
        <h2>User Profile</h2>
       <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
          <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
          <?php echo e($message); ?>

        </div>
         <?php endif; ?>
        <form name="registration" method="post" action="<?php echo e(url('user/postuserProfile')); ?>">
          <?php echo csrf_field(); ?>
          <div class="form-group">
            <label for="email">First Name:</label>
            <input type="text" class="form-control" id="fname" placeholder="Enter First Name" name="fname" value="<?php echo e($user_data['fname']); ?>">
          </div>
          <div class="form-group">
            <label for="email">Last Name</label>
            <input type="text" class="form-control" id="lname" placeholder="Enter Last Name" name="lname" value="<?php echo e($user_data['lname']); ?>">
          </div>
          <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo e($user_data['email']); ?>">
          </div>
          <div class="form-group">
            <label for="email">Profile Image:</label>
            <input type="file" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo e($user_data['email']); ?>">
          </div>
          
          
          <button type="submit" class="btn btn-default">Update Profile</button>
        </form>
      </div>
    </div>
    <!-- <div id="tab-2" style="display: block;">
        <p>Phasellus pharetra aliquet viverra. Donec scelerisque tincidunt diam, eu fringilla urna auctor at.</p>
    </div> -->
</div>
      
  </div>	
</div>  

<!-- <div class="container">
<form method="post" action="<?php echo e(url('submitUser')); ?>">
	<?php echo csrf_field(); ?>
	<input type="text" name="fname" placeholder="first_name">
	<input type="text" name="lname" placeholder="last_name">
	<input type="email" name="email" placeholder="email">
	<input type="password" name="password" placeholder="password">
	<input type="submit" name="btn" value="submit">
</form>
</div> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script>
	$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='registration']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      fname: "required",
      lname: "required",
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    // Specify validation error messages
    messages: {
      fname: "Please enter your firstname",
      lname: "Please enter your lastname",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});
// From http://learn.shayhowe.com/advanced-html-css/jquery

// Change tab class and display content
$('.tabs-nav .tab-link').on('click', function (event) {
    event.preventDefault();
    
    $('.tab-active').removeClass('tab-active');
    $(this).parent().addClass('tab-active');
    $('.tabs-stage .tab-stage-div').hide();
    $($(this).attr('href')).show();
});

$('.tabs-nav a:first').trigger('click'); // Default
</script><?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Front/userProfile.blade.php ENDPATH**/ ?>