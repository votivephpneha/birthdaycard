<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<style>
	.error{
		color:red;
	}
	.user_registration{
		width:500px;
		margin: auto;
	}
</style>

<div class="container">
  <div class="user_registration">
      <h2>User Login</h2>
      <?php if($message = Session::get('email_error')): ?>
      <div class="alert alert-danger">
      	  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		  <?php echo e($message); ?>

	  </div>
	   <?php endif; ?>
      <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
      	  <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
		  <?php echo e($message); ?>

	  </div>
	   <?php endif; ?>
	  <form name="loginUser" method="post" action="<?php echo e(url('submitLoginUser')); ?>">
	  	<?php echo csrf_field(); ?>
	    
	    <div class="form-group">
	      <label for="email">Email:</label>
	      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email">
	    </div>
	    <div class="form-group">
	      <label for="pwd">Password:</label>
	      <input type="password" class="form-control" id="password" placeholder="Enter password" name="password">
	    </div>
	    
	    <button type="submit" class="btn btn-default">Login</button>
	  </form>
  </div>	
</div>  
<!-- <div class="container">
<form method="post" action="<?php echo e(url('submitUser')); ?>">
	<?php echo csrf_field(); ?>
	<input type="text" name="fname" placeholder="first_name">
	<input type="text" name="lname" placeholder="last_name">
	<input type="email" name="email" placeholder="email">
	<input type="password" name="password" placeholder="password">
	<input type="submit" name="btn" value="submit">
</form>
</div> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.1/jquery.validate.min.js"></script>
<script>
	$(function() {
  // Initialize form validation on the registration form.
  // It has the name attribute "registration"
  $("form[name='loginUser']").validate({
    // Specify validation rules
    rules: {
      // The key name on the left side is the name attribute
      // of an input field. Validation rules are defined
      // on the right side
      fname: "required",
      lname: "required",
      email: {
        required: true,
        // Specify that email should be validated
        // by the built-in "email" rule
        email: true
      },
      password: {
        required: true,
        minlength: 5
      }
    },
    // Specify validation error messages
    messages: {
      fname: "Please enter your firstname",
      lname: "Please enter your lastname",
      password: {
        required: "Please provide a password",
        minlength: "Your password must be at least 5 characters long"
      },
      email: "Please enter a valid email address"
    },
    // Make sure the form is submitted to the destination defined
    // in the "action" attribute of the form when valid
    submitHandler: function(form) {
      form.submit();
    }
  });
});

</script><?php /**PATH /home3/votivjhg/public_html/Birthdaycards/resources/views/Front/login.blade.php ENDPATH**/ ?>