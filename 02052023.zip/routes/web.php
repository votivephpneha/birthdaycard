<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\UserController;
use App\Http\Controllers\CardController;
use App\Http\Controllers\MessageController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\CardSizeController;
use App\Http\Controllers\AdminPagesController;
use App\Http\Controllers\Front\CustomerController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::get('/config-cache', function() {
    $exitCode = Artisan::call('config:cache');
    $exitCode = Artisan::call('config:clear');
	$exitCode = Artisan::call('route:clear');
	$exitCode = Artisan::call('view:clear');
    return '<h1>config cache cleared</h1>'; 
});

Route::get('/cache', function() {
	Artisan::call('config:cache');
    Artisan::call('config:clear');
	Artisan::call('route:clear');
	
});

//Front Module

Route::get('/registration',[CustomerController::class,'index'])->name('registration');
Route::post('/submitUser',[CustomerController::class,'submitUser'])->name('submitUser');
Route::get('/loginUser',[CustomerController::class,'loginUser'])->name('loginUser');
Route::post('/submitLoginUser',[CustomerController::class,'submitLoginUser'])->name('submitLoginUser');
Route::group(['prefix' => 'user', 'middleware' => 'customer_auth'], function () { 
	Route::get('/userProfile',[CustomerController::class,'userProfile'])->name('userProfile');
	Route::post('/postuserProfile',[CustomerController::class,'postuserProfile'])->name('postuserProfile');
	Route::get('/user_ChangePassword',[CustomerController::class,'user_ChangePassword'])->name('user_ChangePassword');
	Route::post('/postuser_ChangePassword',[CustomerController::class,'postuser_ChangePassword'])->name('postuser_ChangePassword');
	Route::get('/front_logout', [CustomerController::class, 'front_logout'])->name('front_logout');
});
//Admin Module

Route::get('/admin',[AuthController::class,'index'])->name('login');
Route::post('/login',[AuthController::class,'adminLogin'])->name('login.post');
// apply midddleware
Route::group(['prefix' => 'admin', 'middleware' => 'auth'], function () { 

Route::get('/dashboard',[DashboardController::class,'dashboard'])->name('dashboard');


Route::get('/logout', [AuthController::class, 'logout'])->name('logout');

Route::get('/changepassword',[AuthController::class,'ChangePassword'])->name('chagepassword');
Route::post('/changepassword',[AuthController::class,'ChangePasswordSubmit'])->name('chagepassword.post');

// customer management routes
Route::get('/userlist',[UserController::class,'Userlist'])->name('userlist');
Route::get('/get-userlist',[UserController::class,'GetUsers'])->name('get-userlist');

Route::get('/add-customer',[UserController::class,'AddCustomer'])->name('add-customer');
Route::post('/add-customer',[UserController::class,'AddCustomerPost'])->name('add-customer.post');

Route::get('/edit-customer/{id}',[UserController::class,'EditUser'])->name('edit-customer');
Route::post('/edit-customer/{id}',[UserController::class,'UpdateCustomer'])->name('edit-customer-post');

Route::get('/delete-customer/{id}',[UserController::class,'deleteCustomer'])->name('delete-customer-post');

// card management routes
Route::get('/cardlist',[CardController::class,'index'])->name('cardlist');
Route::get('/create-card',[CardController::class,'create'])->name('create.card');
Route::post('/create-card',[CardController::class,'store'])->name('create.card.post');
Route::get('/getcardlist',[CardController::class,'getCardlist'])->name('get.cardlist');
Route::get('/editcard/{id}',[CardController::class,'edit'])->name('edit.card');
Route::post('/editcard/{id}',[CardController::class,'update'])->name('edit.card.post');
Route::post('/delete-card',[CardController::class,'destroy'])->name('delete.card.post');
Route::get('/viewcard/{id}',[CardController::class,'show'])->name('view.card');
Route::get('/delete_card_images/{id}',[CardController::class,'card_gallery_delete'])->name('delete-card-images');
Route::post('/status-change12',[CardController::class,'Status_change'])->name('status.change');


//message management routes
Route::get('/textmessagelist',[MessageController::class,'index'])->name('messagelist');
Route::get('/create-message',[MessageController::class,'create'])->name('create.message');
Route::post('/create-message',[MessageController::class,'store'])->name('create.message.post');
Route::get('/getmessagelist',[MessageController::class,'getTextmessagelist'])->name('get.messagelist');
Route::get('/edittextmessage/{id}',[MessageController::class,'edit'])->name('edit.message');
Route::post('/edittextmessage/{id}',[MessageController::class,'update'])->name('edit.message.post');
Route::post('/delete-message',[MessageController::class,'destroy'])->name('delete.message.post');

// card category management
Route::get('/cardcategorylist',[CategoryController::class,'index'])->name('categorylist');
Route::get('/create-category',[CategoryController::class,'create'])->name('create.category');
Route::post('/create-category',[CategoryController::class,'store'])->name('create.category.post');
Route::get('/getcategorylist',[CategoryController::class,'getCategorylist'])->name('get.categorylist');
Route::get('/edit-card-category/{id}',[CategoryController::class,'show'])->name('edit.category');
Route::post('/edit-card-category/{id}',[CategoryController::class,'edit'])->name('edit.category.post');
Route::post('/delete-category',[CategoryController::class,'destroy'])->name('delete.category.post');

//card size management
Route::get('/card-size-list',[CardSizeController::class,'index'])->name('cardsizelist');
Route::get('/create-card_size',[CardSizeController::class,'create'])->name('create.card.size');
Route::post('/create-card_size',[CardSizeController::class,'store'])->name('create.card.size.post');
Route::get('/getcardsizelist',[CardSizeController::class,'getCardSizelist'])->name('get.cardsizelist');
Route::post('/delete-card-size',[CardSizeController::class,'destroy'])->name('delete.card.size.post');

// Content management Routes
Route::get('/content-pagelist',[AdminPagesController::class,'index'])->name('content-pagelist');
Route::get('/create-new-page',[AdminPagesController::class,'create'])->name('create.new.page');
Route::post('/create-new-page',[AdminPagesController::class,'store'])->name('create.new.page.post');
Route::get('/getpagelist',[AdminPagesController::class,'getPagelist'])->name('get.pagelist');
Route::get('/edit-page/{id}',[AdminPagesController::class,'edit'])->name('edit.page');
Route::post('/edit-page/{id}',[AdminPagesController::class,'update'])->name('edit.page.post');
Route::post('/delete-page',[AdminPagesController::class,'destroy'])->name('delete.page.post');
});

