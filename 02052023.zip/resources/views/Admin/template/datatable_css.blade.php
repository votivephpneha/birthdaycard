<!-- Bootstrap -->
<link href="{{ asset('public/vendors/bootstrap/dist/css/bootstrap.min.css')}}" rel="stylesheet">
<!-- Font Awesome -->
<link href="{{ asset('public/vendors/font-awesome/css/font-awesome.min.css')}}" rel="stylesheet">

<!-- Custom Theme Style -->
<link href="{{ asset('public/build/css/custom.min.css')}}" rel="stylesheet">

    <!-- datatable styles -->
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.3/css/jquery.dataTables.min.css">   