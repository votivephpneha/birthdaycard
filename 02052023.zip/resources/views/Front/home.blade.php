<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Brithday store</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <link href="assets/img/faviconc.png" rel="icon">
  
<link href="https://fonts.googleapis.com/css2?family=Kalam:wght@300;400;700&family=Source+Sans+Pro:wght@200;300;400;600;700&display=swap" rel="stylesheet">

  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <link href="assets/css/style.css" rel="stylesheet">


  
</head>

<body>



  <header id="header" class="fixed-top">
 
    <div class="container d-flex-brith align-items-center justify-content-between mt-2 bord-top-b">
     <a href="index.html" class="logo"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar">
         <div id="custom-search-input">
                            <div class="input-group col-md-12">
                                <input type="text" class="search" placeholder="search for product..." />
                                <span class="input-group-btn">
                                    <button class="btn btn-danger" type="button">
                                      <i class='bx bx-search'></i>
                                       
                                    </button>
                                </span>
                            </div>
                        </div>
        <ul>
           <li class="dropdown">
            <a href="#"><i class='bx bx-menu'></i></a>
            <ul>
              <li><a href="#">BIRTHDAY CARDS</a></li>
              <li><a href="#">WRAPPING PAPERS</a></li>
              <li><a href="#">MONEY CLIPS</a></li>
              <li><a href="#">PHONE ACCESSORIES</a></li>
              <li><a href="#">BLOG</a></li>
              <li><a href="#">CONTACT US</a></li>
            </ul>
          </li>
        
            <li><a class="nav-link" href="#"><i class='bx bx-user-circle'></i></a></li>
          <li><a class="nav-link " href="#"><i class='bx bx-cart'></i></a></li>
         
          <!-- <li><a class="nav-link " href="#"><i class='bx bx-search' style="font-size: 20px;"></i></a></li> -->
          <li><a class="getstarted " href="signup.html"> Design Your Card</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

</div>
</div>
  <!-- ======= Hero Section ======= -->

  <section class="gift">
    <div class="container">
      <div class="row">
        <div class="col-md-12 giftb">

        <h5>  Favourite Gifts </h5>
        <div class="favii-git col-md-6 m-auto">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua.</p>

</div>
        </div>

    </div>
  </section>

  <section id="hero">

    <div id="heroCarousel" data-bs-interval="5000" class="carousel slide carousel-fade" data-bs-ride="carousel">

      <ol class="carousel-indicators" id="hero-carousel-indicators"></ol>

      <div class="carousel-inner" role="listbox">

        <!-- Slide 1 -->
    
    <div class="carousel-item active" style="background-image: url(assets/img/slider.jpg)">
          <div class="carousel-container">
            <div class="container">
               <div class="col-md-12 text-center">
                <div class="mb-auto">
            <a href="#" class="btn-get-started animate__animated animate__fadeInUp mr-5 ">View Card Designs</a>
             <a href="#" class="btn-get-started animate__animated animate__fadeInUp ">Design Your Card</a>
           </div>
            </div>
            </div>
          </div>
        </div>
        <!-- Slide 2 -->
        <div class="carousel-item " style="background-image: url(assets/img/slider.jpg)">
          <div class="carousel-container">
            <div class="container">
            
            </div>
          </div>
        </div>

        <!-- Slide 3 -->
        <div class="carousel-item" style="background-image: url(assets/img/slider.jpg)">
          <div class="carousel-container">
            <div class="container">
          
            </div>
          </div>
        </div>

      </div>

   <!--    <a class="carousel-control-prev" href="#heroCarousel" role="button" data-bs-slide="prev">
        <span class="carousel-control-prev-icon bi bi-chevron-left" aria-hidden="true"></span>
      </a>

      <a class="carousel-control-next" href="#heroCarousel" role="button" data-bs-slide="next">
        <span class="carousel-control-next-icon bi bi-chevron-right" aria-hidden="true"></span>
      </a>
 -->
    </div>
  </section><!-- End Hero -->



 <section class="giftb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

        <h5>  Favourite Gifts </h5>
        <div class="favii-git col-md-6 m-auto">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua.</p>

</div>
        </div>

    </div>
  </section>



 <section id="why-us" class="why-us section-bg">
      <div class="container-fluid" data-aos="fade-up">

        <div class="row">

          <div class="col-lg-8 m-auto align-items-stretch video-box" style='background-image: url("assets/img/video-img.png");' data-aos="zoom-in" data-aos-delay="100">
            <a href="https://www.youtube.com/watch?v=jDDaplaOz7Q" class="venobox play-btn mb-4" data-vbtype="video" data-autoplay="true"></a>
          </div>


          <div class="col-md-12 text-center mt-4">  <a href="#" class="view-allbotm"> Design Your Card </a></div>
        </div>
      </div>
    </section>


<section id="gridbar" class="grdi-zi mt-5">
      <div class="row p-0 m-0">
<div class="col-md-6">
 <div class="text-grid">
  <div class="favorit-grid">
  <h4>Favourite Gifts </h4>
  <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore  magna aliqua.</p>
</div>

 </div>
</div>

<div class="col-md-6 p-0">
  <div class="imge-brid">
<img src="assets/img/grid2.png">

</div>
</div>

<div class="col-md-6 p-0">
  <div class="imge-brid">
<img src="assets/img/grid1.png">

</div>
</div>

<div class="col-md-6">
 <div class="text-grid">
  <div class="favorit-grid">
  <h4>Favourite Gifts </h4>
  <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore  magna aliqua.</p>
</div>

 </div>
</div>

<div class="col-md-6">
 <div class="text-grid">
  <div class="favorit-grid">
  <h4>Favourite Gifts </h4>
  <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore  magna aliqua.</p>
</div>

 </div>
</div>

<div class="col-md-6 p-0">
  <div class="imge-brid">
<img src="assets/img/grid2.png">

</div>
</div>


<div class="col-md-6 p-0">
  <div class="imge-brid">
<img src="assets/img/grid1.png">

</div>
</div>

<div class="col-md-6">
 <div class="text-grid">
  <div class="favorit-grid">
  <h4>Favourite Gifts </h4>
  <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore  magna aliqua.</p>
</div>

 </div>
</div>

</div>


    </section>


   <section class="giftb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

        <h5>  Favourite Gifts </h5>
        <div class="favii-git col-md-6 m-auto">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua.</p>

</div>
        </div>
<div class="col-md-6">
<div class="boey-box">
<img src="assets/img/boye.png">
</div>
</div>
<div class="col-md-6">
<div class="boey-box">
<img src="assets/img/video-img.png">
</div>
</div>

<div class="col-md-12 text-center mt-4">  <a href="#" class="view-allbotm"> Design Your Card </a></div>


    </div>
  </section>

  


   <section  id="testimonials" class="testimonials section-bg giftb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

        <h5>  Favourite Gifts </h5>
        <div class="favii-git col-md-6 m-auto">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua.</p>

      </div>
        </div>
         <div class="testimonials-slider lover-img swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love1.png" class="testimonial-img" alt="">
                 </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love2.png" class="testimonial-img" alt="">
                
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love3.png" class="testimonial-img" alt="">
                
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love4.png" class="testimonial-img" alt="">
                 
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love2.png" class="testimonial-img" alt="">
                 
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
         <!--  <div class="swiper-pagination"></div> -->
           <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
        </div>

</div>
</div>
</section>


<section  id="testimonials" class="testimonials section-bg giftb">
    <div class="container">
      <div class="row">
        <div class="col-md-12">

        <h5>  Favourite Cards </h5>
        <div class="favii-git col-md-6 m-auto">
  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt
ut labore et dolore magna aliqua.</p>

      </div>
        </div>
         <div class="testimonials-slider lover-img swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">
            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love1.png" class="testimonial-img" alt="">
                 </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love2.png" class="testimonial-img" alt="">
                
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love3.png" class="testimonial-img" alt="">
                
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love4.png" class="testimonial-img" alt="">
                 
                </div>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-wrap">
                <div class="testimonial-item">
                  <img src="assets/img/love2.png" class="testimonial-img" alt="">
                 
                </div>
              </div>
            </div><!-- End testimonial item -->

          </div>
         <!--  <div class="swiper-pagination"></div> -->
           <div class="swiper-button-next"></div>
    <div class="swiper-button-prev"></div>
        </div>

        <div class="col-md-12 text-center mt-4">  <a href="#" class="view-allbotm"> Design Your Card </a></div>

</div>
</div>
</section>



<section class="section-bg">
    <div class="container">
      <div class="row">
        <div class="col-md-3">
          <div class="how-it-work">
            <div class="plane">
           <img src="assets/img/plene.png">
            </div>
            <div class="servi-text">
            <h5>Free delivery within UK </h5>
            <p> No minimum order required,
order only what you need
when you need it and never
worry about shipping!</p>
              </div>
          </div>
        </div>

          <div class="col-md-3">
          <div class="how-it-work">
            <div class="plane">
           <img src="assets/img/plene.png">
            </div>
            <div class="servi-text">
            <h5>Satisfied or Refunded </h5>
            <p>If you not happy with your
order, rest assure we will
cover returns shipment!</p>
              </div>
          </div>
        </div>
          <div class="col-md-3">
          <div class="how-it-work">
            <div class="plane">
           <img src="assets/img/plene.png">
            </div>
            <div class="servi-text">
            <h5>Top-notch Syupport</h5>
            <p> Call Us, Email Us, Or Text Us
We are here for you!</p>
              </div>
          </div>
        </div>
          <div class="col-md-3">
          <div class="how-it-work">
            <div class="plane">
           <img src="assets/img/plene.png">
            </div>
            <div class="servi-text">
            <h5>Secure Payments </h5>
            <p>Shopping on our store is
secure and easy, with military
grade payment gateway!
adipiscing elit. Aenean</p>
              </div>
          </div>
        </div>

      </div>
    </div>
  </section>

  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row mb-5">

           <div class="col-lg-3 col-md-6 ">
             <a href="#" class="logo-foter"><img src="assets/img/logo.png" class="mb-2"> </a>

            <div class="footer-newsletter">
                <h4 class="fowl">Follow Us</h4>
             <a href="#"><img src="assets/img/insta.png" class="mb-2"> </a>
             <a href="#"><img src="assets/img/face.png" class="mb-2"> </a>
             <a href="#"><img src="assets/img/YouTube.png" class="mb-2"> </a>
             <a href="#"><img src="assets/img/tik.png" class="mb-2"> </a>
           </div>
             <div class="mt-3">
              <h4 class="fowl mb-1">We Accept </h4>
             <a href="#"><img src="assets/img/cvxcv4.png" class="mb-2 w-100a"></a>
            <a href="#"> <img src="assets/img/payment-method 2.png" class="mb-2 w-100a"></a>
             
            </div>
          </div>

             <div class="col-lg-4 col-md-6 footer-links-addres">
               <h4>Contact Us</h4>
             
              <ul>
              <li> <a href="#"><img src="assets/img/Vector.png"> Address 5171 Will Goes
Here</a></li>
              <li> <a href="#"><img src="assets/img/Vector-1.png"> Call Us 0123456789</a></li>
               <li> <a href="#"> <img src="assets/img/ic_outline-email.png"> Email info@gmail.com</a></li>
                
            </ul>
          </div>


          <div class="col-lg-3 col-md-6 footer-links">
               <h4>Quick Links</h4>
             
              <ul>
              <li> <a href="#"> Home</a></li>
              <li> <a href="#">About</a></li>
               <li> <a href="#">Birthday Cards</a></li>
              <li> <a href="#">Video Message Cards</a></li>
              <li> <a href="#">Personalised Gifts</a></li>
              <li> <a href="#">Create Your Card</a></li>
              
            </ul>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Account</h4>
            <ul>
              <li> <a href="#"> Sign In</a></li>
              <li> <a href="#">View Cart</a></li>
               <li> <a href="#">My Wishlist</a></li>
              <li> <a href="#">Track My Order</a></li>
              <li> <a href="#">Shipping Details</a></li>
              <li> <a href="#">Help Ticket</a></li>
              
            </ul>
          </div>

         

        </div>
      </div>
    </div>

    <div class="brith-foter">
      <div class="copyright" style="font-size: 12px;">
        © 2023<strong> <span>Brithday store.</span></strong> All rights reserved
      </div>
     
    </div>
  </footer> <!-- End Footer







  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
  

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>